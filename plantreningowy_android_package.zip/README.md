PlanTreningowy - Android app skeleton and GitHub Actions workflow
================================================================
This archive contains a minimal Android Studio project skeleton with source files,
a GitHub Actions workflow to build a debug APK (assembleDebug) and upload it as an artifact.

Steps to use (from a phone):
1. Create a new GitHub repo (via mobile browser or GitHub app).
2. Upload all files from this ZIP into the repository (you can upload via the GitHub web UI).
3. On GitHub, go to Actions -> find the workflow 'android-build.yml' and allow it to run.
4. After workflow completes, open the workflow run and download the artifact 'app-debug-apk' (contains app-debug.apk).
5. Download the APK to your phone and install (enable 'Install unknown apps' for your browser/file manager).

Notes:
- This project is a skeleton. Opening in Android Studio on a PC/Mac allows more comfortable development.
- The workflow uses the 'gradle/gradle-build-action' action so the repository does NOT need the Gradle wrapper.
- If the build fails on Actions due to SDK/licensing, see the README instructions created in the repo for troubleshooting.
