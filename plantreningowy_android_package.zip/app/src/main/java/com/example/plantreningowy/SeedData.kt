package com.example.plantreningowy

data class ExerciseSeed(val id:String, val name:String, val muscles:String, val youtube:String)

object SeedData {
    fun all(): List<ExerciseSeed> {
        return listOf(
            ExerciseSeed("bench_flat", "Bench Press (sztanga)", "Klatka piersiowa, triceps", "https://www.youtube.com/watch?v=vcBig73ojpE"),
            ExerciseSeed("incline_db", "Incline DB Press", "Górna klatka", "https://www.youtube.com/watch?v=hChjZQhX1Ls"),
            ExerciseSeed("cable_fly", "Cable Fly", "Przyśrodkowa część klatki", "https://www.youtube.com/watch?v=8Um35Es-ROE"),
            ExerciseSeed("deadlift", "Deadlift", "Plecy, glutes", "https://www.youtube.com/watch?v=op9kVnSso6Q")
        )
    }
}
